## Section 1: Requirements
- Week View
- Event and Task Creation
- Commitment Warnings
- Persistence

## Section 2: Headlining Features
- Task Queue
- Categories

## Section 3: Power Ups
- Quotes and Notes
- Progress Bar
- Weekly Overview

## Section 4: Quality of Life
- Links
- Mind Changes

## Section 5: Extra Credit
- Visual Flourish
- Splash Screen
- Privacy Lock
- Weekly Starters