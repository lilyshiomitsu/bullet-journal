package cs3500.pa05.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AcalendarItemTest {
//  AcalendarItem testItem;
//
//  @BeforeEach
//  void setup() {
//  //  testItem = new AcalendarItem("Test", "For PA05", Day.FRIDAY, "N/A");
//  }
//
//  @Test
//  void getName() {
//    assertEquals("Test", testItem.getName());
//  }
//
//  @Test
//  void setName() {
//    testItem.setName("NotNotTest");
//    assertEquals("NotNotTest", testItem.getName());
//  }
//
//  @Test
//  void getDescription() {
//    assertEquals("For PA05", testItem.getDescription());
//  }
//
//  @Test
//  void setDescription() {
//    testItem.setDescription("Asks the TAs for help");
//    assertEquals("Asks the TAs for help", testItem.getDescription());
//  }
//
//  @Test
//  void getDayOfWeek() {
//    assertEquals(Day.FRIDAY, testItem.getDayOfWeek());
//  }
//
//  @Test
//  void setDayOfWeek() {
//    testItem.setDayOfWeek(Day.SATURDAY);
//    assertEquals(Day.SATURDAY, testItem.getDayOfWeek());
//  }
//
//  @Test
//  void getCategory() {
//    assertEquals("N/A", testItem.getCategory());
//  }
//
//  @Test
//  void setCategory() {
//    testItem.setCategory("Testing");
//    assertEquals("Testing", testItem.getCategory());
//  }
//
//  @Test
//  void setIsComplete() {
//    assertDoesNotThrow(() -> testItem.setIsComplete(true));
//  }

  //  @Test
  //  void emptyConstructor() {
  //    AcalendarItem item = new AcalendarItem();
  //    assertEquals("", item.getName());
  //    assertEquals("", item.getDescription());
  //    assertNull(item.getDayOfWeek());
  //    assertNull(item.getCategory());
  //  }
}